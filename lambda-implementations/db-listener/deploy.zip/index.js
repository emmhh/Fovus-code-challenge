const { EC2Client, RunInstancesCommand } = require("@aws-sdk/client-ec2");
const ec2Client = new EC2Client({ region: "us-east-1" });

async function launchInstanceWithPrimaryKey(primaryKey) {
    const userDataScript = `#!/bin/bash echo ${primaryKey} > /tmp/primaryKey.txt; curl -H "Content-Type: application/json" -d '{"input_text": "output test from ec2 curl", "input_file": "output_test"}' -X POST https://yl9zletvr9.execute-api.us-east-1.amazonaws.com/dev`;

    const command = new RunInstancesCommand({
        ImageId: "ami-xxxxxxx", // Specify your AMI ID
        InstanceType: "t2.micro",
        MinCount: 1,
        MaxCount: 1,
        UserData: Buffer.from(userDataScript).toString('base64'),
        IamInstanceProfile:{
            Name: "fovus-ec2-role"
        }
    });

    try {
        const data = await ec2Client.send(command);
        console.log("Success", data);
        // Additional code to handle the response
    } catch (err) {
        console.log("Error", err);
    }
}

export const handler = async (event) => {
    try {
        // Iterate over each record in the event
        for (const record of event.Records) {
            if (record.eventName === 'INSERT') {
                // Extract the primary key value from the record
                const primaryKey = record.dynamodb.Keys.id.S;
                // Launch EC2 instance with the extracted primary key
                await launchInstanceWithPrimaryKey(primaryKey);
            }
        }
    } catch (error) {
        console.error("Error:", error);
    }
};

// export const handler = async (event) => {
//     for (const record of event.Records) {
//         if (record.eventName === 'INSERT') {
//             const primaryKey = record.dynamodb.Keys.id.S;
//             await launchInstanceWithPrimaryKey(primaryKey);
//         }
//     }
// };
